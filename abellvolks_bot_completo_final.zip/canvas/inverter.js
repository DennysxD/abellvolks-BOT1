module.exports = {
    commands: ["inverter"],
    description: "🖼️ Aplicando efeito Inverter...",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `🖼️ Aplicando efeito Inverter... $`.trim(),
            quoted
        });
    }
};