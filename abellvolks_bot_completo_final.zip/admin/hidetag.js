module.exports = {
    commands: ["hidetag"],
    description: "📢 Mensagem enviada para todos.",
    onlyOwner: false,
    onlyAdmins: true,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `📢 Mensagem enviada para todos. $`.trim(),
            quoted
        });
    }
};