module.exports = {
    commands: ["kick"],
    description: "👢 Usuário expulso!",
    onlyOwner: false,
    onlyAdmins: true,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `👢 Usuário expulso! $`.trim(),
            quoted
        });
    }
};