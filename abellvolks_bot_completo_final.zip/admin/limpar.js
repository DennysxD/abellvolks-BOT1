module.exports = {
    commands: ["limpar"],
    description: "🧹 (mock) Limpeza ativada!",
    onlyOwner: false,
    onlyAdmins: true,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `🧹 (mock) Limpeza ativada! $`.trim(),
            quoted
        });
    }
};