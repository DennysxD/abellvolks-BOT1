module.exports = {
    commands: ["ban"],
    description: "🚫 Usuário banido com sucesso!",
    onlyOwner: false,
    onlyAdmins: true,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `🚫 Usuário banido com sucesso! $`.trim(),
            quoted
        });
    }
};