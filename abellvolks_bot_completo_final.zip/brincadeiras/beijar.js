module.exports = {
    commands: ["beijar"],
    description: "💋 Você deu um beijo em",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `💋 Você deu um beijo em ${param}`.trim(),
            quoted
        });
    }
};