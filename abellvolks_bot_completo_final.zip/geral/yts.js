module.exports = {
    commands: ["yts"],
    description: "📺 (mock) Resultado da pesquisa no YouTube...",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `📺 (mock) Resultado da pesquisa no YouTube... $`.trim(),
            quoted
        });
    }
};