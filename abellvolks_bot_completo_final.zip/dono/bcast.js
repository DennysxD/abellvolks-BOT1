module.exports = {
    commands: ["bcast"],
    description: "📢 Mensagem enviada para todos os grupos.",
    onlyOwner: true,
    onlyAdmins: false,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `📢 Mensagem enviada para todos os grupos. $`.trim(),
            quoted
        });
    }
};