module.exports = {
    commands: ["getid"],
    description: "🆔 Seu ID é:",
    onlyOwner: true,
    onlyAdmins: false,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `🆔 Seu ID é: $`.trim(),
            quoted
        });
    }
};