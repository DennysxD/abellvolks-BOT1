module.exports = {
    commands: ["gpt4"],
    description: "🤖 (mock GPT-4) Resposta:",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `🤖 (mock GPT-4) Resposta: $`.trim(),
            quoted
        });
    }
};