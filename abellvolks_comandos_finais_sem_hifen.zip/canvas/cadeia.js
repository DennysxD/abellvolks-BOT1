module.exports = {
    commands: ["cadeia"],
    description: "Aplica efeito: cadeia",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message) {
        await client.sendMessage(message.key.remoteJid, {
            text: "🖼️ (mock) Aplicando efeito cadeia..."
        });
    }
};