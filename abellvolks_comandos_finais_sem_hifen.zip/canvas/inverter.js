module.exports = {
    commands: ["inverter"],
    description: "Aplica efeito: inverter",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message) {
        await client.sendMessage(message.key.remoteJid, {
            text: "🖼️ (mock) Aplicando efeito inverter..."
        });
    }
};