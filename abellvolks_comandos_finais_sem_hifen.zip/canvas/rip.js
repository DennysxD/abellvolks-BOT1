module.exports = {
    commands: ["rip"],
    description: "Aplica efeito: rip",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message) {
        await client.sendMessage(message.key.remoteJid, {
            text: "🖼️ (mock) Aplicando efeito rip..."
        });
    }
};