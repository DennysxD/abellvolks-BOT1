module.exports = {
    commands: ["bolsonaro"],
    description: "Aplica efeito: bolsonaro",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message) {
        await client.sendMessage(message.key.remoteJid, {
            text: "🖼️ (mock) Aplicando efeito bolsonaro..."
        });
    }
};