module.exports = {
    commands: ["matar"],
    description: "Brincadeira: matar",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const alvo = args.join(" ") || "alguém";
        await client.sendMessage(message.key.remoteJid, {
            text: `😈 Você mandou um(a) *matar* em {alvo}!`
        });
    }
};