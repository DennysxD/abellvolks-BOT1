module.exports = {
    commands: ["socar"],
    description: "Brincadeira: socar",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const alvo = args.join(" ") || "alguém";
        await client.sendMessage(message.key.remoteJid, {
            text: `😈 Você mandou um(a) *socar* em {alvo}!`
        });
    }
};