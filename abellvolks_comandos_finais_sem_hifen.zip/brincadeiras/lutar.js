module.exports = {
    commands: ["lutar"],
    description: "Brincadeira: lutar",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const alvo = args.join(" ") || "alguém";
        await client.sendMessage(message.key.remoteJid, {
            text: `😈 Você mandou um(a) *lutar* em {alvo}!`
        });
    }
};