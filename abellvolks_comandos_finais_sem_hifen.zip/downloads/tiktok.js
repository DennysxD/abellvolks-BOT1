module.exports = {
    commands: ["tik-tok"],
    description: "Baixa vídeo do TikTok (mock)",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const url = args[0];
        if (!url) return client.sendMessage(message.key.remoteJid, { text: "😈 Envie o link do TikTok." });
        await client.sendMessage(message.key.remoteJid, { text: `🎬 (mock) Baixando TikTok: ${url}` });
    }
};