module.exports = {
    commands: ["play-video"],
    description: "Toca vídeo de música (mock)",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const song = args.join(" ");
        if (!song) return client.sendMessage(message.key.remoteJid, { text: "😈 Envie o nome do vídeo." });
        await client.sendMessage(message.key.remoteJid, { text: `📺 (mock) Tocando: ${song}` });
    }
};