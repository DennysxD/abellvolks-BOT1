module.exports = {
    commands: ["play-audio"],
    description: "Toca áudio de música (mock)",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const song = args.join(" ");
        if (!song) return client.sendMessage(message.key.remoteJid, { text: "😈 Envie o nome da música." });
        await client.sendMessage(message.key.remoteJid, { text: `🎵 (mock) Tocando: ${song}` });
    }
};