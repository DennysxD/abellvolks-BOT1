module.exports = {
    commands: ["yt-mp4"],
    description: "Baixa vídeo do YouTube (mock)",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const url = args[0];
        if (!url) return client.sendMessage(message.key.remoteJid, { text: "😈 Envie o link do vídeo." });
        await client.sendMessage(message.key.remoteJid, { text: `🎥 (mock) Baixando vídeo de: ${url}` });
    }
};