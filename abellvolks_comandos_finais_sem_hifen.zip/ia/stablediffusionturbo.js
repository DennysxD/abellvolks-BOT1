module.exports = {
    commands: ["stable-diffusion-turbo"],
    description: "Imagem com Stable Diffusion (mock)",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message) {
        await client.sendMessage(message.key.remoteJid, { text: "🧠 (mock) Gerando imagem com Stable Diffusion..." });
    }
};