module.exports = {
    commands: ["pixart"],
    description: "Imagem com IA estilo PixArt (mock)",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message) {
        await client.sendMessage(message.key.remoteJid, { text: "🧠 (mock) Gerando imagem estilo PixArt..." });
    }
};