module.exports = {
    commands: ["gpt-4"],
    description: "Chat IA com GPT-4 (mock)",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const prompt = args.join(" ");
        if (!prompt) return client.sendMessage(message.key.remoteJid, { text: "😈 Digite algo para a IA." });
        await client.sendMessage(message.key.remoteJid, { text: `🤖 (mock GPT-4) Resposta: ${prompt}` });
    }
};