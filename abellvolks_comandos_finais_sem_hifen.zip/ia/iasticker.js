module.exports = {
    commands: ["ia-sticker"],
    description: "Cria sticker com IA (mock)",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message) {
        await client.sendMessage(message.key.remoteJid, { text: "🤖 (mock) Criando sticker com IA..." });
    }
};