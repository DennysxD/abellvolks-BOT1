module.exports = {
    commands: ["cep"],
    description: "📍 Resultado da consulta de CEP (mock)",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `📍 Resultado da consulta de CEP (mock) $`.trim(),
            quoted
        });
    }
};