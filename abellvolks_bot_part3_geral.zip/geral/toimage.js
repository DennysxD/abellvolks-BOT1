module.exports = {
    commands: ["toimage"],
    description: "📸 (mock) Convertendo sticker em imagem...",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `📸 (mock) Convertendo sticker em imagem... $`.trim(),
            quoted
        });
    }
};