module.exports = {
    commands: ["on"],
    description: "Confirma que o bot está online",
    onlyOwner: true,
    onlyAdmins: false,
    async execute(client, message) {
        await client.sendMessage(message.key.remoteJid, { text: "😈 Estou online e operando, chefe!" });
    }
};