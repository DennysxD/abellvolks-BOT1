module.exports = {
    commands: ["exec"],
    description: "Executa código JavaScript remotamente",
    onlyOwner: true,
    onlyAdmins: false,
    async execute(client, message, args) {
        const code = args.join(" ");
        try {
            const result = await eval(code);
            await client.sendMessage(message.key.remoteJid, { text: `✅ Resultado:
${result}` });
        } catch (err) {
            await client.sendMessage(message.key.remoteJid, { text: `❌ Erro:
${err.message}` });
        }
    }
};