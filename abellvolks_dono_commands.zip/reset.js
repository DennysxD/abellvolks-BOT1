module.exports = {
    commands: ["reset"],
    description: "Reinicia o bot",
    onlyOwner: true,
    onlyAdmins: false,
    async execute(client, message) {
        await client.sendMessage(message.key.remoteJid, { text: "😈 Reiniciando o bot..." });
        process.exit(1);
    }
};