module.exports = {
    commands: ["bcast"],
    description: "Envia mensagem para todos os grupos",
    onlyOwner: true,
    onlyAdmins: false,
    async execute(client, message, args) {
        const text = args.join(" ");
        if (!text) {
            return client.sendMessage(message.key.remoteJid, { text: "😈 Escreva uma mensagem para enviar." });
        }

        const chats = await client.groupFetchAllParticipating();
        for (const id in chats) {
            await client.sendMessage(id, { text });
        }

        await client.sendMessage(message.key.remoteJid, { text: "✅ Mensagem enviada a todos os grupos." });
    }
};