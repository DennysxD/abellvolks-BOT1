module.exports = {
    commands: ["off"],
    description: "Desliga o bot",
    onlyOwner: true,
    onlyAdmins: false,
    async execute(client, message) {
        await client.sendMessage(message.key.remoteJid, { text: "😈 Bot desligando..." });
        process.exit(0);
    }
};