module.exports = {
    commands: ["get-id"],
    description: "Mostra o ID do grupo ou do usuário",
    onlyOwner: true,
    onlyAdmins: false,
    async execute(client, message) {
        const jid = message.key.remoteJid;
        const resposta = jid.endsWith("@g.us")
            ? `🆔 ID do grupo:
${jid}`
            : `🆔 Seu ID:
${jid}`;
        await client.sendMessage(jid, { text: resposta });
    }
};