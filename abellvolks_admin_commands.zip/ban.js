module.exports = {
    commands: ["ban"],
    description: "Remove um usuário marcado do grupo",
    onlyAdmins: true,
    onlyOwner: false,
    async execute(client, message) {
        const chatId = message.key.remoteJid;
        if (!chatId.endsWith("@g.us")) return;

        const mentioned = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        if (mentioned.length === 0) {
            return client.sendMessage(chatId, { text: "😈 Marque alguém para banir." });
        }

        for (const user of mentioned) {
            await client.groupParticipantsUpdate(chatId, [user], "remove");
        }

        await client.sendMessage(chatId, { text: "😈 Usuário(s) removido(s)!" });
    }
};