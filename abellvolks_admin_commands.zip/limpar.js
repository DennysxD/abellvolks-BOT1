module.exports = {
    commands: ["limpar"],
    description: "Limpa as mensagens do bot no chat",
    onlyAdmins: true,
    onlyOwner: false,
    async execute(client, message) {
        await client.sendMessage(message.key.remoteJid, { text: "😈 Limpeza visual ativada. (mensagens antigas não são apagadas por limitações da API)." });
    }
};