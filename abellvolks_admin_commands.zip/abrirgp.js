module.exports = {
    commands: ["abrirgp"],
    description: "Abre o grupo para todos falarem",
    onlyAdmins: true,
    onlyOwner: false,
    async execute(client, message) {
        if (!message.key.remoteJid.endsWith("@g.us")) {
            return client.sendMessage(message.key.remoteJid, { text: "😈 Este comando só funciona em grupos." });
        }
        await client.groupSettingUpdate(message.key.remoteJid, "not_announcement");
        await client.sendMessage(message.key.remoteJid, { text: "😈 Grupo aberto com sucesso!" });
    }
};