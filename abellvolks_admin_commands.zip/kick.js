module.exports = {
    commands: ["kick"],
    description: "Expulsa um membro do grupo",
    onlyAdmins: true,
    onlyOwner: false,
    async execute(client, message) {
        const chatId = message.key.remoteJid;
        if (!chatId.endsWith("@g.us")) return;

        const mentioned = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        if (mentioned.length === 0) {
            return client.sendMessage(chatId, { text: "😈 Marque alguém para kickar." });
        }

        for (const user of mentioned) {
            await client.groupParticipantsUpdate(chatId, [user], "remove");
        }

        await client.sendMessage(chatId, { text: "😈 Membro expulso com sucesso!" });
    }
};