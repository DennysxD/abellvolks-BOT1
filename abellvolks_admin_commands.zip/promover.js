module.exports = {
    commands: ["promover"],
    description: "Promove um membro a admin",
    onlyAdmins: true,
    onlyOwner: false,
    async execute(client, message) {
        const chatId = message.key.remoteJid;
        if (!chatId.endsWith("@g.us")) return;

        const mentioned = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        if (mentioned.length === 0) {
            return client.sendMessage(chatId, { text: "😈 Marque alguém para promover." });
        }

        for (const user of mentioned) {
            await client.groupParticipantsUpdate(chatId, [user], "promote");
        }

        await client.sendMessage(chatId, { text: "😈 Membro promovido a admin!" });
    }
};