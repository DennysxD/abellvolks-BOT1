module.exports = {
    commands: ["rebaixar"],
    description: "Remove o cargo de admin de um membro",
    onlyAdmins: true,
    onlyOwner: false,
    async execute(client, message) {
        const chatId = message.key.remoteJid;
        if (!chatId.endsWith("@g.us")) return;

        const mentioned = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        if (mentioned.length === 0) {
            return client.sendMessage(chatId, { text: "😈 Marque alguém para rebaixar." });
        }

        for (const user of mentioned) {
            await client.groupParticipantsUpdate(chatId, [user], "demote");
        }

        await client.sendMessage(chatId, { text: "😈 Membro rebaixado com sucesso!" });
    }
};