module.exports = {
    commands: ["hidetag"],
    description: "Envia uma mensagem marcada para todos",
    onlyAdmins: true,
    onlyOwner: false,
    async execute(client, message, args) {
        const group = message.key.remoteJid;
        const text = args.join(" ") || "😈";
        const metadata = await client.groupMetadata(group);
        const members = metadata.participants.map(u => u.id);

        await client.sendMessage(group, {
            text,
            mentions: members
        });
    }
};