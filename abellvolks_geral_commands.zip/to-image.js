module.exports = {
    commands: ["to-image"],
    description: "Converte sticker em imagem (mock)",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message) {
        await client.sendMessage(message.key.remoteJid, {
            text: "🖼️ (mock) Convertendo sticker para imagem..."
        });
    }
};