module.exports = {
    commands: ["cep"],
    description: "Consulta informações de um CEP (mock)",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const cep = args[0];
        if (!cep) return client.sendMessage(message.key.remoteJid, { text: "😈 Informe um CEP para consulta." });
        await client.sendMessage(message.key.remoteJid, {
            text: `😈 Resultado da consulta CEP ${cep}:
Rua Exemplo, Bairro Legal, Cidade XYZ`
        });
    }
};