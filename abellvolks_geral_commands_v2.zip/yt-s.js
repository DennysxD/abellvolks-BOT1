module.exports = {
    commands: ["yt-s"],
    description: "Faz uma busca no YouTube (mock)",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const query = args.join(" ");
        if (!query) return client.sendMessage(message.key.remoteJid, { text: "😈 Digite algo para pesquisar no YouTube." });
        await client.sendMessage(message.key.remoteJid, {
            text: `📺 Resultado da busca (mock):
1. ${query} - YouTube Vídeo Exemplo`
        });
    }
};