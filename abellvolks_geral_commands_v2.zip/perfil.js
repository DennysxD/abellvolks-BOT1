module.exports = {
    commands: ["perfil"],
    description: "Mostra informações básicas do usuário",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message) {
        const jid = message.key.participant || message.key.remoteJid;
        const number = jid.replace(/[@:\s\D]/g, "");
        await client.sendMessage(message.key.remoteJid, {
            text: `😈 Perfil do usuário:
• Número: ${number}`
        });
    }
};