module.exports = {
    commands: ["attp"],
    description: "Transforma texto em sticker animado (mock)",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const text = args.join(" ");
        if (!text) return client.sendMessage(message.key.remoteJid, { text: "😈 Digite um texto para gerar o sticker." });
        await client.sendMessage(message.key.remoteJid, {
            text: `🌀 (mock) Gerando sticker animado com: "${text}"`
        });
    }
};