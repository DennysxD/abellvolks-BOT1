module.exports = {
    commands: ["ping"],
    description: "Testa se o bot está online",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message) {
        await client.sendMessage(message.key.remoteJid, { text: "😈 Pong!" });
    }
};