module.exports = {
    commands: ["fig"],
    description: "Cria um sticker (mock)",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message) {
        await client.sendMessage(message.key.remoteJid, {
            text: "🖼️ (mock) Criando sticker..."
        });
    }
};