module.exports = {
    commands: ["ttp"],
    description: "Transforma texto em imagem",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const text = args.join(" ");
        if (!text) return client.sendMessage(message.key.remoteJid, { text: "😈 Informe o texto para gerar a imagem." });
        await client.sendMessage(message.key.remoteJid, {
            text: `🖼️ (mock) Gerando imagem com: "${text}"`
        });
    }
};