module.exports = {
    commands: ["socar"],
    description: "👊 Você deu um soco em",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `👊 Você deu um soco em ${param}`.trim(),
            quoted
        });
    }
};