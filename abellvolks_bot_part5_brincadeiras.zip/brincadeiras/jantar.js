module.exports = {
    commands: ["jantar"],
    description: "🍽️ Você convidou para jantar:",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `🍽️ Você convidou para jantar: ${param}`.trim(),
            quoted
        });
    }
};