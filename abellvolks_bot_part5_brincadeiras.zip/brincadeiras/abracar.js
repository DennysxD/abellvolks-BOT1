module.exports = {
    commands: ["abracar"],
    description: "🤗 Você mandou um abraço em",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `🤗 Você mandou um abraço em ${param}`.trim(),
            quoted
        });
    }
};