const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const config = require('./src/config');
const { loadCommands } = require('./src/loader');

const client = new Client({
    authStrategy: new LocalAuth({
        dataPath: './.wwebjs_auth'
    }),
    puppeteer: {
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    }
});

client.on('qr', qr => {
    qrcode.generate(qr, { small: true });
    console.log(`[${config.BOT_NAME}] Escaneie o QR Code acima com seu WhatsApp`);
});

client.on('ready', () => {
    console.log(`[${config.BOT_NAME}] BOT está pronto e conectado! 😈`);
});

client.on('message', async (message) => {
    try {
        await loadCommands(client, message);
    } catch (err) {
        console.error('Erro ao processar comando:', err);
    }
});

client.initialize();
