const path = require("path");

exports.PREFIX = "/";
exports.BOT_EMOJI = "😈";
exports.BOT_NAME = "AbellVolks BOT";
exports.BOT_NUMBER = "556191450237";
exports.OWNER_NUMBER = "556194333182";

exports.COMMANDS_DIR = path.join(__dirname, "commands");
exports.DATABASE_DIR = path.resolve(__dirname, "..", "database");
exports.ASSETS_DIR = path.resolve(__dirname, "..", "assets");
exports.TEMP_DIR = path.resolve(__dirname, "..", "assets", "temp");

exports.TIMEOUT_IN_MILLISECONDS_BY_EVENT = 700;

exports.SPIDER_API_BASE_URL = "https://api.spiderx.com.br/api";
exports.SPIDER_API_TOKEN = "jAmgywdviZAfN863qYmG";
exports.ONLY_GROUP_ID = "";
exports.BASE_DIR = path.resolve(__dirname);
