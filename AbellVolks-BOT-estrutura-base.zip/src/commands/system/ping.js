module.exports = {
    name: "ping",
    description: "Retorna o tempo de resposta do bot.",
    async execute(client, message, args) {
        const tempo = Date.now() - message.timestamp * 1000;
        await message.reply(`🏓 Pong! Tempo de resposta: *${tempo}ms*`);
    }
};
