const fs = require("fs");
const path = require("path");
const config = require("./config");

exports.loadCommands = async (client, message) => {
    const prefix = config.PREFIX;
    if (!message.body.startsWith(prefix)) return;

    const args = message.body.slice(prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    const folders = fs.readdirSync(config.COMMANDS_DIR);

    for (const folder of folders) {
        const folderPath = path.join(config.COMMANDS_DIR, folder);
        const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));

        for (const file of commandFiles) {
            const command = require(path.join(folderPath, file));
            if (command.name === commandName) {
                return command.execute(client, message, args);
            }
        }
    }
};
