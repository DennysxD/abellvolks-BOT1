module.exports = {
    commands: ["bolsonaro"],
    description: "🖼️ Aplicando efeito Bolsonaro...",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `🖼️ Aplicando efeito Bolsonaro... $`.trim(),
            quoted
        });
    }
};