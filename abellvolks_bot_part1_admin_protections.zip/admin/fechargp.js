module.exports = {
    commands: ["fechargp"],
    description: "🔒 Grupo fechado com sucesso!",
    onlyOwner: false,
    onlyAdmins: true,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `🔒 Grupo fechado com sucesso! $`.trim(),
            quoted
        });
    }
};