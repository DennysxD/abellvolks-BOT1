module.exports = {
    commands: ["abrirgp"],
    description: "📣 Grupo aberto com sucesso!",
    onlyOwner: false,
    onlyAdmins: true,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `📣 Grupo aberto com sucesso! $`.trim(),
            quoted
        });
    }
};