module.exports = {
    commands: ["playvideo"],
    description: "📺 (mock) Tocando vídeo...",
    onlyOwner: false,
    onlyAdmins: false,
    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message;
        const param = args.join(" ") || "ninguém";

        await client.sendMessage(from, {
            text: `📺 (mock) Tocando vídeo... $`.trim(),
            quoted
        });
    }
};